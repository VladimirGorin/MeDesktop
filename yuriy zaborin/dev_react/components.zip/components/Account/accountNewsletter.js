// eslint-disable-line
import React from 'react';

export const AccountNewsletter = () => {
    return (
        <>
            <h1>AccountNewsletter</h1>
        </>
    );
};
